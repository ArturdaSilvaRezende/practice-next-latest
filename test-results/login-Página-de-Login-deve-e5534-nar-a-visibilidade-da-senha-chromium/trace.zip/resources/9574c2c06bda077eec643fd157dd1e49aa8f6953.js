(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_next_07o-6cu._.js","static/chunks/node_modules_react-select_dist_10cqtw6._.js","static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ezz.e5._.js","static/chunks/node_modules_0n24yio._.js","static/chunks/_0x9whz-._.js"],
    source: "dynamic"
});
